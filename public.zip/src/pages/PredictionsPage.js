import React from 'react';
import PredictionDashboard from '../components/PredictionDashboard';
export default PredictionDashboard;
