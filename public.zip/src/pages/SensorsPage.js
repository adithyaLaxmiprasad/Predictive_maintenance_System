import React from 'react';
import SensorDashboard from '../components/SensorDashboard';
export default SensorDashboard;
