import React from 'react';
import AssetTracker from '../components/AssetTracker';
export default AssetTracker;
